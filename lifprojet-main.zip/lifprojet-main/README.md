# LifProjet

#Utiliser le fichier vehicules.csv pour tester CleandData.py

#Utiliser le fichier Vehicules_final.csv pour tester DataVisualization.py et Models.py

#Veillez à changer le chemin des fichiers dans le code ( déjà commenté dans le code )

#Le fichier CleanData.py est réalisé en parallèle avec DataVisualization.py (quoi supprimer et quoi changer)

#Le fichier DataVisualization.py contient aussi l'exploration des données à analyser

#Le fichier Models.py contient différents modèles de machine learning supervisés à choisir ( xgboost meilleure performance dans ce cas )

#Le dossier Application contient le fichier App.py (site statique de test non fini)

#Le fichier LinearRegression.ipynb à tester directement en entrant les paramètres voulu dans les pipe.predict


