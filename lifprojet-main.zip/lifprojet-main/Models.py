#importer les packages
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import math
from sklearn.ensemble import RandomForestRegressor
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
# Necessary imports
 from sklearn.metrics import mean_squared_error as MSE
 import xgboost as xgb



#changer le chemin d'openFile pour tester

def Random_forest :
    #ouvrir le fichier csv
    openFile=pd.read_csv(r'C:\Users\etulyon1\Vehicules_lkher.csv')
    df = pd.DataFrame(openFile)

    #choix des features
    df = df.select_dtypes(exclude=['object'])
    df=df.fillna(df.mean())
    X = df.drop('price',axis=1)
    y = df['price']


    #fit 
    regressor = RandomForestRegressor(n_estimators = 1000, random_state = 42)
    regressor.fit(X_train, y_train)

    #get prediction
    y_pred = regressor.predict(X_test)

    #affichage des  pridected and actual price
    df=pd.DataFrame({'Actual':y_test, 'Predicted':y_pred})


    #model_validation  RMSE

    mse = mean_squared_error(y_test, y_pred)
    rmse = math.sqrt(mse)
    print('Rmse BY Random forest',rmse)


    #creation du fichier reultat csv
    df.to_csv("Resultats_RandomForest.csv",index=False)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
# Recover default matplotlib settings
plt.rcParams.update(plt.rcParamsDefault)
%matplotlib inline
plt.figure(figsize=(9,9))
#Predicted and real values
sns.regplot(x = y_test,y = y_pred, color='#FF6600')
plt.xlabel('Y Test (True Values)')
plt.ylabel('Predicted values')
plt.show()




def XGBoost :
    #ouvrir le fichier
    openFile=pd.read_csv(r'C:\Users\etulyon1\Vehicules_lkher.csv')
    df = pd.DataFrame(openFile)


    # Select subset of predictors
    cols_to_use = ['year', 'condition', 'fuel', 'odometer','cylinders','transmission']
    X = openFile[cols_to_use]

    # Select target
    target_variable='price'
    target='Predictedprice'
    y = openFile.price

    #split data
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=0)


    #fit
    from sklearn.metrics import mean_absolute_error
    from xgboost import XGBRegressor
    my_model = XGBRegressor(n_estimators=1000, learning_rate=0.05, n_jobs=4)
    my_model.fit(X_train, y_train, 
                early_stopping_rounds=5, 
                eval_set=[(X_valid, y_valid)], 
                verbose=False)

    #model validation

    mae_1 = mean_absolute_error(predictions_1, y_valid) 
    print("Mean Absolute Error by XGBoost: " , mae_1)

    # Calculate r2
    r2_score_1 = r2_score(y_valid,predictions_1)
    print("R2 Score by XGBoost: ", r2_score_1)


   



    def KNN:
        
    openFile=pd.read_csv(r'C:\Users\etulyon1\Vehicules_lkher.csv')
    df = pd.DataFrame(openFile)
    # Select subset of predictors
    cols_to_use = ['year', 'condition', 'fuel', 'odometer','cylinders','transmission']
    X = openFile[cols_to_use]

    # Select target
    target_variable='price'
    target='Predictedprice'
    y = openFile.price

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_saize=0.4, random_state=0)

    # (KNN)
    from sklearn.neighbors import KNeighborsRegressor
    RegModel = KNeighborsRegressor(n_neighbors=3)

    #Les parametres de KNN
    print(RegModel)

    # Creation du model 
    KNN=RegModel.fit(X_train,y_train)
    prediction=KNN.predict(X_test)


    from sklearn import metrics
    #Calcule du R2 value
    print('R2 Value:',metrics.r2_score(y_train, KNN.predict(X_train)))


    #Model Validation

    #Affichage des resultats 
    TestingDataResults=pd.DataFrame(data=X_test, columns=cols_to_use)
    TestingDataResults[target_variable]=y_test
    TestingDataResults[('Predicted'+target_variable)]=np.round(prediction)

    # affichage prediction valeur 
    print(TestingDataResults[[target_variable,'Predicted'+target_variable]].head())



    # Verification des score valeur
    def Accuracy_Score(orig,pred):
    MAPE = np.mean(100 * (np.abs(orig-pred)/orig))
    return(100-MAPE)


    from sklearn.metrics import make_scorer
    custom_Scoring=make_scorer(Accuracy_Score, greater_is_better=True)

    from sklearn.model_selection import cross_val_score

    #affichage de la moyen de precision
    Accuracy_Values=cross_val_score(RegModel, X , y, cv=10, scoring=custom_Scoring)
    print('\nAccuracy values for 10-fold Cross Validation:\n',Accuracy_Values)
    print('\nFinal Average Accuracy of the model:', round(Accuracy_Values.mean(),2))





def Linear_regression:
    openFile=pd.read_csv(r'C:\Users\etulyon1\Vehicules_lkher.csv')
    df = pd.DataFrame(openFile)

    # Select subset of predictors
    cols_to_use = ['year', 'condition', 'fuel', 'odometer','cylinders','transmission']
    X = openFile[cols_to_use]

    # Select target
    target_variable='price'
    target='Predictedprice'
    y = openFile.price

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=0)

    from sklearn.linear_model import LinearRegression
    reg=LinearRegression(normalize =True)
    reg.fit(X_train,y_train)

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    %matplotlib inline
    # Recover default matplotlib settings
    plt.rcParams.update(plt.rcParamsDefault)
    %matplotlib inline
    plt.figure(figsize=(9,9))
    sns.regplot(x = y_test,y = pred, color='#FF6600')
    plt.xlabel('Y Test (True Values)')
    plt.ylabel('Predicted values')
    plt.show()

    reg.score(X_test,y_test)
