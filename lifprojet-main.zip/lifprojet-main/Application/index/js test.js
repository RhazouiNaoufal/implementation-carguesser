window.onload= function(){
    
     var test=this.document.getElementsByClassName("research").addEventListener("keyUp",rechercher);


}

void rechercher(){


}


