
from flask import Flask,render_template,url_for,request
from flask.json import jsonify
from numpy import positive


app = Flask(__name__)



@app.route('/', methods=['GET', 'POST'])

#charger la page
def index():
    rec = False
    if request.method == 'POST' :
        form=request.form
        rec = recup(form)
    return render_template('lif-projet.html',rec=rec)

#Récupérer les données entrées par l'utilisateur
def recup(form):
    marque = request.form['marque']
    model= request.form['model']
    fuel = request.form['fuel']
    transmission = request.form['transmission']
    year = request.form['year']

    return 0

#traiter les données entrées par l'utilisateur (non fini)
@app.route('/traite', methods=['POST','GET'])
def traite():
    if request.method == "POST":
        dataval=request.get_json()
        print (dataval)
    results={'processed': 'true'}
    return jsonify(results)

if __name__ == '__main__':
    app.debug = True
    app.run()